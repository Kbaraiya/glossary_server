const express = require("express");
const fs = require("fs");
const path = require("path");

const router = express.Router();

// Path to the orders.json file
const ordersFilePath = path.join(__dirname, "../orders.json");

// ✅ GET: Fetch all orders
router.get("/", (req, res) => {
    fs.readFile(ordersFilePath, "utf8", (err, data) => {
        if (err) {
            console.error("Error reading orders.json:", err);
            return res.status(500).json({ error: "Unable to read orders" });
        }

        try {
            const orders = data ? JSON.parse(data) : [];
            res.json(orders);
        } catch (parseError) {
            console.error("Error parsing orders.json:", parseError);
            return res.status(500).json({ error: "Corrupted orders data" });
        }
    });
});

// ✅ POST: Save a new order
router.post("/", (req, res) => {
    const newOrder = req.body;

    // Read existing orders
    fs.readFile(ordersFilePath, "utf8", (err, data) => {
        let orders = [];

        if (!err && data) {
            try {
                orders = JSON.parse(data);
            } catch (parseError) {
                console.error("Error parsing orders.json:", parseError);
                return res.status(500).json({ error: "Corrupted orders data" });
            }
        }

        // Add new order
        orders.push(newOrder);

        // Save back to file
        fs.writeFile(ordersFilePath, JSON.stringify(orders, null, 2), (err) => {
            if (err) {
                console.error("Error writing to orders.json:", err);
                return res.status(500).json({ error: "Unable to save order" });
            }

            res.status(200).json({ message: "Order saved successfully" });
        });
    });
});

module.exports = router;
